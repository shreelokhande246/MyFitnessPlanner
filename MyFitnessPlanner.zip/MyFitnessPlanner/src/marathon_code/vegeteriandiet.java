package marathon_code;

public class vegeteriandiet {

	

}
