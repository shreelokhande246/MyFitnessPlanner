package marathon_code;

import java.util.Scanner;

public class mainclass {
	
public static void main(String[] args) {
	{
        System.out.println("-------------------------------------------------------------------------------------");
       
        System.out.println("                                                                                                                             ");
        System.out.println("                                                                                                                                                  ");

        System.out.println("                             Welcome to MyFitnessPlanner                                ");
        System.out.println("                                                                                                                                                  ");
        System.out.println("                                                                                                                                                  ");
     
        System.out.println("--------------------------------------------------------------------------------------");
        System.out.println("     ");
    }
	menu a = new menu();
	a.menu1();
	
}
}
