package marathon_code;

public class begvariation {
String mname;
int reps;
int set;

begvariation(String mname, int reps, int set)
{
	this.mname = mname;
	this.reps = reps;
	this.set = set;
}
begvariation()
{
	
}

public void variation1()
{
	begvariation b = new begvariation("Chest flat bench - Dumbbell Press ",15,3);
	begvariation b1 = new begvariation("Shoulder overhead - Dumbbell Press ",15,3);
	begvariation b2= new begvariation("Back - Latpull Down ",15,3);
	begvariation b3 = new begvariation("Bicep - Dumbbell Curls ",15,3);
	begvariation b4 = new begvariation("Tricep - Pushdown rod ",15,3);
	begvariation b5 = new begvariation("Standing Squats ",15,3);
	System.out.println("__________________________________________________________");
	System.out.println(" ");
	System.out.println(" Workout name: " +b.mname);
	System.out.println(" Repetitions: " +b.reps);
	System.out.println(" Sets: " +b.set);
	System.out.println(" ");
	
	System.out.println(" Workout name: " +b1.mname);
	System.out.println(" Repetitions: " +b1.reps);
	System.out.println(" Sets: " +b1.set);
	System.out.println(" ");
	
	System.out.println(" Workout name: " +b2.mname);
	System.out.println(" Repetitions: " +b2.reps);
	System.out.println(" Sets: " +b2.set);
	System.out.println(" ");
	
	System.out.println(" Workout name: " +b3.mname);
	System.out.println(" Repetitions: " +b3.reps);
	System.out.println(" Sets: " +b3.set);
	System.out.println(" ");
	
	System.out.println(" Workout name: " +b4.mname);
	System.out.println(" Repetitions: " +b4.reps);
	System.out.println(" Sets: " +b4.set);
	System.out.println(" ");
	
	System.out.println(" Workout name: " +b5.mname);
	System.out.println(" Repetitions: " +b5.reps);
	System.out.println(" Sets: " +b5.set);
	System.out.println(" ");
	System.out.println("Repeat the above variation for 3-4 weeks");
	System.out.println("__________________________________________________________");
	
	
}
public void variation2()
{
	begvariation b = new begvariation("Chest incline bench - Dumbbell Press ",15,3);
	begvariation b1 = new begvariation("Shoulder front rows - Dumbbell ",15,3);
	begvariation b2= new begvariation("Back - Seated row ",15,3);
	begvariation b3 = new begvariation("Bicep - Hammer Dumbbell Curls ",15,3);
	begvariation b4 = new begvariation("Tricep - Pushdown rope ",15,3);
	begvariation b5 = new begvariation("Leg extension ",15,3);
	System.out.println("__________________________________________________________");
	System.out.println(" ");
	System.out.println(" Workout name: " +b.mname);
	System.out.println(" Repetitions: " +b.reps);
	System.out.println(" Sets: " +b.set);
	System.out.println(" ");
	
	System.out.println(" Workout name: " +b1.mname);
	System.out.println(" Repetitions: " +b1.reps);
	System.out.println(" Sets: " +b1.set);
	System.out.println(" ");
	
	System.out.println(" Workout name: " +b2.mname);
	System.out.println(" Repetitions: " +b2.reps);
	System.out.println(" Sets: " +b2.set);
	System.out.println(" ");
	
	System.out.println(" Workout name: " +b3.mname);
	System.out.println(" Repetitions: " +b3.reps);
	System.out.println(" Sets: " +b3.set);
	System.out.println(" ");
	
	System.out.println(" Workout name: " +b4.mname);
	System.out.println(" Repetitions: " +b4.reps);
	System.out.println(" Sets: " +b4.set);
	System.out.println(" ");
	
	System.out.println(" Workout name: " +b5.mname);
	System.out.println(" Repetitions: " +b5.reps);
	System.out.println(" Sets: " +b5.set);
	System.out.println(" ");
	System.out.println("Repeat the above variation for 3-4 weeks");
	System.out.println("__________________________________________________________");
	
	
}
public void variation3()
{
	begvariation b = new begvariation("Chest decline bench - Dumbbell Press ",15,3);
	begvariation b1 = new begvariation("Shoulder Lateral raise - Dumbbell ",15,3);
	begvariation b2= new begvariation("Back - Dumbbell rows ",15,3);
	begvariation b3 = new begvariation("Bicep - Preacher Curls ",15,3);
	begvariation b4 = new begvariation("Tricep - Pushdown reverse rod ",15,3);
	begvariation b5 = new begvariation("Leg curls ",15,3);
	System.out.println("__________________________________________________________");
	System.out.println(" ");
	System.out.println(" Workout name: " +b.mname);
	System.out.println(" Repetitions: " +b.reps);
	System.out.println(" Sets: " +b.set);
	System.out.println(" ");
	
	System.out.println(" Workout name: " +b1.mname);
	System.out.println(" Repetitions: " +b1.reps);
	System.out.println(" Sets: " +b1.set);
	System.out.println(" ");
	
	System.out.println(" Workout name: " +b2.mname);
	System.out.println(" Repetitions: " +b2.reps);
	System.out.println(" Sets: " +b2.set);
	System.out.println(" ");
	
	System.out.println(" Workout name: " +b3.mname);
	System.out.println(" Repetitions: " +b3.reps);
	System.out.println(" Sets: " +b3.set);
	System.out.println(" ");
	
	System.out.println(" Workout name: " +b4.mname);
	System.out.println(" Repetitions: " +b4.reps);
	System.out.println(" Sets: " +b4.set);
	System.out.println(" ");
	
	System.out.println(" Workout name: " +b5.mname);
	System.out.println(" Repetitions: " +b5.reps);
	System.out.println(" Sets: " +b5.set);
	System.out.println(" ");
	System.out.println("Repeat the above variation for 3-4 weeks");
	System.out.println("__________________________________________________________");
	
	
}
public void variation4()
{
	begvariation b = new begvariation("Chest seated flies ",15,3);
	begvariation b1 = new begvariation("Shoulder reverse flies ",15,3);
	begvariation b2= new begvariation("Back - shrugs ",15,3);
	begvariation b3 = new begvariation("Bicep - Reverse curls ",15,3);
	begvariation b4 = new begvariation("Tricep - overhead extension ",15,3);
	begvariation b5 = new begvariation("Standing lunges ",15,3);
	System.out.println("__________________________________________________________");
	System.out.println(" ");
	System.out.println(" Workout name: " +b.mname);
	System.out.println(" Repetitions: " +b.reps);
	System.out.println(" Sets: " +b.set);
	System.out.println(" ");
	
	System.out.println(" Workout name: " +b1.mname);
	System.out.println(" Repetitions: " +b1.reps);
	System.out.println(" Sets: " +b1.set);
	System.out.println(" ");
	
	System.out.println(" Workout name: " +b2.mname);
	System.out.println(" Repetitions: " +b2.reps);
	System.out.println(" Sets: " +b2.set);
	System.out.println(" ");
	
	System.out.println(" Workout name: " +b3.mname);
	System.out.println(" Repetitions: " +b3.reps);
	System.out.println(" Sets: " +b3.set);
	System.out.println(" ");
	
	System.out.println(" Workout name: " +b4.mname);
	System.out.println(" Repetitions: " +b4.reps);
	System.out.println(" Sets: " +b4.set);
	System.out.println(" ");
	
	System.out.println(" Workout name: " +b5.mname);
	System.out.println(" Repetitions: " +b5.reps);
	System.out.println(" Sets: " +b5.set);
	System.out.println(" ");
	System.out.println("Repeat the above variation for 3-4 weeks");
	System.out.println("__________________________________________________________");
	
	
}



}
