//package marathon_code;
//
//import java.util.Scanner;
//
//public class userdetails extends Authentication {
//
//	public void userdet()
//	{
//		Scanner sc = new Scanner(System.in);
//		System.out.print("Enter your gender: ");
//		System.out.print(" ");
//		gender = sc.nextLine();
//		System.out.print("Enter your age: ");
//		System.out.print(" ");
//		Age = sc.nextLine();
//		System.out.print("Enter your height ");
//		System.out.print(" ");
//		height = sc.nextLine();
//		System.out.print("Enter your weight: ");
//		System.out.print(" ");
//		weight = sc.nextLine();
//	}
//}
