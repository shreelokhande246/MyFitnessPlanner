package marathon_code;

public class interworkout {
private String workoutname;
private String sets;
private String reps;


public String getworkoutname()
{
	return workoutname;
}
public void setworkoutname(String workoutname)
{
	this.workoutname = workoutname;
}
public String getsets()
{
	return sets;
}
public void setsets(String sets)
{
	this.sets = sets;
}
public String getreps()
{
	return reps;
}
public void setreps(String reps)
{
	this.reps = reps;
}
}
